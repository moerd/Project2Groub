package com.test.ecommerceft;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class ItemDetailActivity extends AppCompatActivity {

    String name;
    int price;
    int count;
    TextView tvPrice;
    TextView tvCartProductQuantity;
    TextView tvName;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_detail);

        tvPrice = findViewById(R.id.tv_price);
        tvName = findViewById(R.id.tv_name);
        tvCartProductQuantity= findViewById(R.id.cart_product_quantity_tv);

        Bundle bundle = getIntent().getExtras();
        if(bundle != null){
            name = bundle.getString("name");
            price = bundle.getInt("price");
            count = bundle.getInt("count");

            tvPrice.setText("Price: "+price+" $");
            tvName.setText(name);
            tvCartProductQuantity.setText(""+count);
        }


    }
}