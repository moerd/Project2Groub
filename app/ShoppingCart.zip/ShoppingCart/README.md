# Shopping Cart
An android application to demonstrate the concept of E-commerce using Room DB. 

Features:
* Easy. Just add your phone number and name.
* Safe. All data is locally stored.
* Open Source. ShoppingCart is open for everyone. Anyone can edit, modify and learn.

## Authors

* **Hemant Joshi** - [hjoshi123](https://github.com/hjoshi123)

## License

This project is licensed under the GNU LGPL - see the [LICENSE](https://github.com/hjoshi123/ShoppingCart/blob/master/LICENSE) file for details

## Acknowledgments

* Google Android Toolkit Team

